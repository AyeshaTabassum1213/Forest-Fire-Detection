import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage, ref } from 'firebase/storage';
import { getAnalytics, isSupported } from 'firebase/analytics';

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAf_xI-L85rTsKK_46psyelV-3iwH4VbTQ",
  authDomain: "firewatch-3e7f2.firebaseapp.com",
  projectId: "firewatch-3e7f2",
  storageBucket: "firewatch-3e7f2.firebasestorage.app",
  messagingSenderId: "1021037585453",
  appId: "1:1021037585453:web:5dd5ca7a69323b1aa384a4",
  measurementId: "G-NYLPMPL5RP"
};

// Initialize Firebase services with error handling
let app, auth, db, storage, analytics;

try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  storage = getStorage(app);
  
  // Only initialize analytics if supported (browser environment)
  isSupported().then((supported) => {
    if (supported) {
      analytics = getAnalytics(app);
      console.log('Analytics initialized');
    }
  });
  
  console.log('Firebase services initialized successfully');
} catch (error) {
  console.error('Firebase initialization error:', error);
  throw new Error('Failed to initialize Firebase services');
}

export { auth, db, storage, analytics, firebaseConfig };
export const storageRef = ref(storage);
export default app;
