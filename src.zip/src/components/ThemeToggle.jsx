import { useTheme } from '../contexts/ThemeContext';

const ThemeToggle = () => {
  const { darkMode, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-full focus:outline-none"
      aria-label={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
    >
      {darkMode ? (
        <i className="bi bi-sun text-yellow-400"></i>
      ) : (
        <i className="bi bi-moon text-gray-700"></i>
      )}
    </button>
  );
};

export default ThemeToggle;
