import { Link, useLocation } from 'react-router-dom';

const Sidebar = ({ sidebarOpen, setSidebarOpen, userRole }) => {
  const location = useLocation();
  
  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: 'bi-speedometer2' },
    { name: 'Live Detection', href: '/live-detection', icon: 'bi-camera-video' },
    { name: 'Map View', href: '/map', icon: 'bi-map' },
    { name: 'Detection History', href: '/history', icon: 'bi-clock-history' },
    { name: 'Reports', href: '/reports', icon: 'bi-file-earmark-text' },
    { name: 'Settings', href: '/settings', icon: 'bi-gear' },
  ];
  
  // Admin-only navigation items
  if (userRole === 'admin') {
    navigation.push({ name: 'User Management', href: '/users', icon: 'bi-people' });
  }
  
  return (
    <>
      {/* Mobile sidebar backdrop */}
      <div
        className={`fixed inset-0 z-20 bg-gray-600 dark:bg-gray-900 bg-opacity-75 dark:bg-opacity-75 transition-opacity lg:hidden ${
          sidebarOpen ? 'opacity-100 ease-out duration-300' : 'opacity-0 ease-in duration-200 pointer-events-none'
        }`}
        onClick={() => setSidebarOpen(false)}
      ></div>
      
      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-30 w-64 bg-white dark:bg-dark-200 shadow-lg transform transition duration-300 lg:translate-x-0 lg:static lg:inset-0 ${
          sidebarOpen ? 'translate-x-0 ease-out' : '-translate-x-full ease-in'
        }`}
      >
        {/* Sidebar header */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <i className="bi bi-tree text-primary-600 dark:text-primary-400 text-2xl"></i>
            <span className="ml-2 text-xl font-semibold text-gray-800 dark:text-gray-100">FireGuard</span>
          </div>
          <button
            type="button"
            className="lg:hidden text-gray-500 dark:text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
            onClick={() => setSidebarOpen(false)}
          >
            <i className="bi bi-x-lg"></i>
          </button>
        </div>
        
        {/* Sidebar content */}
        <nav className="mt-5 px-2 space-y-1">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`group flex items-center px-2 py-2 text-base font-medium rounded-md ${
                  isActive
                    ? 'bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-dark-300 hover:text-gray-900 dark:hover:text-white'
                }`}
              >
                <i className={`${item.icon} ${
                  isActive 
                    ? 'text-primary-600 dark:text-primary-400' 
                    : 'text-gray-400 dark:text-gray-500 group-hover:text-gray-500 dark:group-hover:text-gray-400'
                } mr-3 text-lg`}></i>
                {item.name}
              </Link>
            );
          })}
        </nav>
        
        {/* Sidebar footer */}
        <div className="absolute bottom-0 w-full p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                <i className="bi bi-person text-primary-600 dark:text-primary-400"></i>
              </div>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-700 dark:text-gray-200">
                {userRole === 'admin' ? 'Administrator' : userRole === 'firefighter' ? 'Firefighter' : 'Forest Officer'}
              </p>
              <p className="text-xs font-medium text-gray-500 dark:text-gray-400">
                {userRole}
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
