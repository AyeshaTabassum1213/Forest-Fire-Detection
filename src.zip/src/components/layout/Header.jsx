import { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useAlerts } from '../../contexts/AlertContext';
import { useTheme } from '../../contexts/ThemeContext';
import ThemeToggle from '../ThemeToggle';

const Header = ({ setSidebarOpen, user }) => {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const { darkMode } = useTheme();
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const userMenuRef = useRef(null);
  const notificationsRef = useRef(null);
  const { signOut } = useAuth();
  const { alerts } = useAlerts();
  const navigate = useNavigate();
  
  // Close menus when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setUserMenuOpen(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target)) {
        setNotificationsOpen(false);
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };
  
  // Get recent notifications (last 5)
  const recentNotifications = alerts.slice(0, 5);
  
  return (
    <header className={`${darkMode ? 'bg-dark-800' : 'bg-white'} shadow-sm z-10`}>
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <button
              type="button"
              className="px-4 text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary-500 lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <i className="bi bi-list text-2xl"></i>
            </button>
            <div className="flex-shrink-0 flex items-center">
              <h1 className={`text-xl font-semibold ${darkMode ? 'text-gray-100' : 'text-gray-800'} hidden lg:block`}>
                Forest Fire Detection System
              </h1>
            </div>
          </div>
          
          <div className="flex items-center">
            {/* Search */}
            <div className="flex-1 flex justify-center px-2 lg:ml-6 lg:justify-end">
              <div className="max-w-lg w-full lg:max-w-xs">
                <label htmlFor="search" className="sr-only">Search</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i className="bi bi-search text-gray-400"></i>
                  </div>
                  <input
                    id="search"
                    name="search"
                    className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    placeholder="Search"
                    type="search"
                  />
                </div>
              </div>
            </div>
            
            {/* Theme Toggle */}
            <div className="ml-4">
              <ThemeToggle />
            </div>
            
            {/* Notifications */}
            <div className="ml-4 relative flex-shrink-0" ref={notificationsRef}>
              <button
                type="button"
                className={`${darkMode ? 'bg-dark-800' : 'bg-white'} p-1 rounded-full text-gray-400 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                onClick={() => setNotificationsOpen(!notificationsOpen)}
              >
                <span className="sr-only">View notifications</span>
                <i className="bi bi-bell text-xl"></i>
                {alerts.length > 0 && (
                  <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-danger-600 ring-2 ring-white"></span>
                )}
              </button>
              
              {/* Notifications dropdown */}
              {notificationsOpen && (
                  <div className={`origin-top-right absolute right-0 mt-2 w-80 rounded-md shadow-lg py-1 ${darkMode ? 'bg-dark-700' : 'bg-white'} ring-1 ring-black dark:ring-gray-600 ring-opacity-5 focus:outline-none`}>
                  <div className="px-4 py-2 border-b border-gray-200">
                    <h3 className="text-sm font-medium text-gray-700">Notifications</h3>
                  </div>
                  <div className="max-h-60 overflow-y-auto">
                    {recentNotifications.length > 0 ? (
                      recentNotifications.map((notification) => (
                        <a
                          key={notification.id}
                          href="#"
                          className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                          onClick={(e) => {
                            e.preventDefault();
                            setNotificationsOpen(false);
                            navigate('/live-detection');
                          }}
                        >
                          <div className="flex items-start">
                            <div className="flex-shrink-0">
                              <i className={`bi ${notification.type === 'fire' ? 'bi-fire text-danger-600' : 'bi-cloud-haze text-warning-600'} text-lg`}></i>
                            </div>
                            <div className="ml-3 w-0 flex-1">
                              <p className="text-sm font-medium text-gray-900">
                                {notification.type === 'fire' ? 'Fire' : 'Smoke'} detected
                              </p>
                              <p className="mt-1 text-xs text-gray-500">
                                {notification.location?.name || 'Unknown location'} • {new Date(notification.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                        </a>
                      ))
                    ) : (
                      <div className="px-4 py-3 text-sm text-gray-500">
                        No new notifications
                      </div>
                    )}
                  </div>
                  <div className="border-t border-gray-200 px-4 py-2">
                    <a
                      href="#"
                      className="text-xs font-medium text-primary-600 hover:text-primary-500"
                      onClick={(e) => {
                        e.preventDefault();
                        setNotificationsOpen(false);
                        navigate('/history');
                      }}
                    >
                      View all notifications
                    </a>
                  </div>
                </div>
              )}
            </div>
            
            {/* Profile dropdown */}
            <div className="ml-4 relative flex-shrink-0" ref={userMenuRef}>
              <div>
                <button
                  type="button"
                  className={`${darkMode ? 'bg-dark-800' : 'bg-white'} rounded-full flex text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                  id="user-menu-button"
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                >
                  <span className="sr-only">Open user menu</span>
                  <div className="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                    <i className="bi bi-person text-primary-600"></i>
                  </div>
                </button>
              </div>
              
              {/* Profile dropdown panel */}
              {userMenuOpen && (
                <div
                  className={`origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 ${darkMode ? 'bg-dark-700' : 'bg-white'} ring-1 ring-black ring-opacity-5 focus:outline-none`}
                  role="menu"
                  aria-orientation="vertical"
                  aria-labelledby="user-menu-button"
                  tabIndex="-1"
                >
                  <div className={`px-4 py-2 text-sm ${darkMode ? 'text-gray-200' : 'text-gray-700'} border-b ${darkMode ? 'border-gray-600' : 'border-gray-200'}`}>
                    <div className={`font-medium ${darkMode ? 'text-gray-100' : ''}`}>{user?.email || 'User'}</div>
                  </div>
                  <a
                    href="#"
                    className={`block px-4 py-2 text-sm ${darkMode ? 'text-gray-200 hover:bg-dark-600' : 'text-gray-700 hover:bg-gray-100'}`}
                    role="menuitem"
                    onClick={(e) => {
                      e.preventDefault();
                      setUserMenuOpen(false);
                      navigate('/settings');
                    }}
                  >
                    <div className="flex items-center">
                      <i className="bi bi-gear mr-2"></i>
                      Settings
                    </div>
                  </a>
                  <a
                    href="#"
                    className={`block px-4 py-2 text-sm ${darkMode ? 'text-gray-200 hover:bg-dark-600' : 'text-gray-700 hover:bg-gray-100'}`}
                    role="menuitem"
                    onClick={(e) => {
                      e.preventDefault();
                      handleSignOut();
                    }}
                  >
                    <div className="flex items-center">
                      <i className="bi bi-box-arrow-right mr-2"></i>
                      Sign out
                    </div>
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
