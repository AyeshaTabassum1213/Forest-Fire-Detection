import { createContext, useContext, useState, useEffect } from 'react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';
import io from 'socket.io-client';

const AlertContext = createContext();

export function useAlerts() {
  return useContext(AlertContext);
}

export function AlertProvider({ children }) {
  const [alerts, setAlerts] = useState([]);
  const [recentAlert, setRecentAlert] = useState(null);
  const [loading, setLoading] = useState(true);
  const [socket, setSocket] = useState(null);
  const { currentUser } = useAuth();

  // Initialize socket connection
  useEffect(() => {
    if (currentUser) {
      const newSocket = io({
        auth: {
          token: currentUser.accessToken
        }
      });
      
      setSocket(newSocket);
      
      return () => {
        newSocket.disconnect();
      };
    }
  }, [currentUser]);

  // Listen for real-time alerts from socket
  useEffect(() => {
    if (socket) {
      socket.on('new-detection', async (data) => {
        try {
          // Store alert in Firestore
          const alertsRef = collection(db, 'alerts');
          await addDoc(alertsRef, {
            ...data,
            timestamp: new Date().toISOString(),
            status: 'new',
            viewed: false
          });
        } catch (error) {
          console.error('Error storing alert:', error);
          toast.error('Failed to store alert');
        }

        setRecentAlert(data);
        
        // Show toast notification
        toast.custom((t) => (
          <div className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-md w-full bg-white shadow-lg rounded-lg pointer-events-auto flex ring-1 ring-black ring-opacity-5`}>
            <div className="flex-1 w-0 p-4">
              <div className="flex items-start">
                <div className="flex-shrink-0 pt-0.5">
                  <i className="bi bi-fire text-danger-600 text-2xl"></i>
                </div>
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium text-gray-900">
                    Fire Detection Alert!
                  </p>
                  <p className="mt-1 text-sm text-gray-500">
                    {data.location.name} - Confidence: {data.confidence}%
                  </p>
                </div>
              </div>
            </div>
            <div className="flex border-l border-gray-200">
              <button
                onClick={() => toast.dismiss(t.id)}
                className="w-full border border-transparent rounded-none rounded-r-lg p-4 flex items-center justify-center text-sm font-medium text-primary-600 hover:text-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-500"
              >
                View
              </button>
            </div>
          </div>
        ), { duration: 5000 });
      });
      
      socket.on('connect_error', (err) => {
        console.error('Socket connection error:', err);
      });
    }
    
    return () => {
      if (socket) {
        socket.off('new-detection');
        socket.off('connect_error');
      }
    };
  }, [socket]);

  // Fetch alerts from Firestore
  useEffect(() => {
    if (!currentUser) return;
    
    const alertsRef = collection(db, 'alerts');
    const alertsQuery = query(
      alertsRef,
      orderBy('timestamp', 'desc'),
      limit(50)
    );
    
    const unsubscribe = onSnapshot(alertsQuery, (snapshot) => {
      const alertsList = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      setAlerts(alertsList);
      setLoading(false);
    }, (error) => {
      console.error('Error fetching alerts:', error);
      setLoading(false);
    });
    
    return () => unsubscribe();
  }, [currentUser]);

  const value = {
    alerts,
    recentAlert,
    loading
  };

  return (
    <AlertContext.Provider value={value}>
      {children}
    </AlertContext.Provider>
  );
}
