import { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, getDocs, startAfter, where } from 'firebase/firestore';
import { db } from '../../firebase';

const DetectionHistory = () => {
  const [detections, setDetections] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastVisible, setLastVisible] = useState(null);
  const [hasMore, setHasMore] = useState(true);
  const [filters, setFilters] = useState({
    type: 'all',
    dateRange: 'all',
    confidence: 'all',
  });
  
  const fetchDetections = async (isInitial = false) => {
    try {
      setLoading(true);
      
      // Build query
      let detectionsRef = collection(db, 'detections');
      let detectionsQuery = query(
        detectionsRef,
        orderBy('timestamp', 'desc'),
        limit(10)
      );
      
      // Apply filters
      if (filters.type !== 'all') {
        detectionsQuery = query(
          detectionsRef,
          where('type', '==', filters.type),
          orderBy('timestamp', 'desc'),
          limit(10)
        );
      }
      
      // Apply pagination
      if (!isInitial && lastVisible) {
        detectionsQuery = query(
          detectionsRef,
          orderBy('timestamp', 'desc'),
          startAfter(lastVisible),
          limit(10)
        );
        
        if (filters.type !== 'all') {
          detectionsQuery = query(
            detectionsRef,
            where('type', '==', filters.type),
            orderBy('timestamp', 'desc'),
            startAfter(lastVisible),
            limit(10)
          );
        }
      }
      
      const detectionsSnapshot = await getDocs(detectionsQuery);
      
      // Check if we have more results
      setHasMore(detectionsSnapshot.docs.length === 10);
      
      // Set the last visible document for pagination
      if (detectionsSnapshot.docs.length > 0) {
        setLastVisible(detectionsSnapshot.docs[detectionsSnapshot.docs.length - 1]);
      } else {
        setLastVisible(null);
      }
      
      // Process results
      const detectionsList = detectionsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      // Apply date range filter client-side
      let filteredDetections = detectionsList;
      if (filters.dateRange !== 'all') {
        const now = new Date();
        let startDate;
        
        switch (filters.dateRange) {
          case 'today':
            startDate = new Date(now.setHours(0, 0, 0, 0));
            break;
          case 'week':
            startDate = new Date(now.setDate(now.getDate() - 7));
            break;
          case 'month':
            startDate = new Date(now.setMonth(now.getMonth() - 1));
            break;
          default:
            startDate = null;
        }
        
        if (startDate) {
          filteredDetections = detectionsList.filter(detection => 
            new Date(detection.timestamp) >= startDate
          );
        }
      }
      
      // Apply confidence filter client-side
      if (filters.confidence !== 'all') {
        const [min, max] = filters.confidence.split('-').map(Number);
        filteredDetections = filteredDetections.filter(detection => 
          detection.confidence >= min && 
          (max ? detection.confidence <= max : true)
        );
      }
      
      if (isInitial) {
        setDetections(filteredDetections);
      } else {
        setDetections(prev => [...prev, ...filteredDetections]);
      }
    } catch (error) {
      console.error('Error fetching detections:', error);
    } finally {
      setLoading(false);
    }
  };
  
  // Initial fetch
  useEffect(() => {
    fetchDetections(true);
  }, [filters]);
  
  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
    setDetections([]);
    setLastVisible(null);
    setHasMore(true);
  };
  
  const loadMore = () => {
    if (!loading && hasMore) {
      fetchDetections();
    }
  };
  
  // Mock data for demo
  const mockDetections = [
    {
      id: '1',
      type: 'fire',
      location: { name: 'North Ridge Forest', coordinates: { lat: 37.7749, lng: -122.4194 } },
      confidence: 92,
      timestamp: new Date('2023-10-15T14:32:00').toISOString(),
      status: 'verified',
      imageUrl: 'https://images.unsplash.com/photo-1611270418597-a6c77f4b7271?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80',
    },
    {
      id: '2',
      type: 'smoke',
      location: { name: 'Eagle Peak', coordinates: { lat: 37.7833, lng: -122.4167 } },
      confidence: 78,
      timestamp: new Date('2023-10-14T09:15:00').toISOString(),
      status: 'verified',
      imageUrl: 'https://images.unsplash.com/photo-1611270418597-a6c77f4b7271?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80',
    },
    {
      id: '3',
      type: 'fire',
      location: { name: 'Redwood Valley', coordinates: { lat: 37.7691, lng: -122.4449 } },
      confidence: 95,
      timestamp: new Date('2023-10-13T17:45:00').toISOString(),
      status: 'verified',
      imageUrl: 'https://images.unsplash.com/photo-1611270418597-a6c77f4b7271?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80',
    },
    {
      id: '4',
      type: 'fog',
      location: { name: 'Misty Mountains', coordinates: { lat: 37.7691, lng: -122.4449 } },
      confidence: 65,
      timestamp: new Date('2023-10-12T07:30:00').toISOString(),
      status: 'pending',
      imageUrl: 'https://images.unsplash.com/photo-1611270418597-a6c77f4b7271?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80',
    },
    {
      id: '5',
      type: 'smoke',
      location: { name: 'Pine Forest', coordinates: { lat: 37.7691, lng: -122.4449 } },
      confidence: 82,
      timestamp: new Date('2023-10-11T13:20:00').toISOString(),
      status: 'verified',
      imageUrl: 'https://images.unsplash.com/photo-1611270418597-a6c77f4b7271?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Detection History</h1>
        <div className="flex space-x-3">
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <i className="bi bi-download mr-2"></i>
            Export
          </button>
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <i className="bi bi-funnel mr-2"></i>
            Advanced Filters
          </button>
        </div>
      </div>
      
      {/* Filters */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label htmlFor="filter-type" className="block text-sm font-medium text-gray-700">
                Detection Type
              </label>
              <select
                id="filter-type"
                name="filter-type"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                value={filters.type}
                onChange={(e) => handleFilterChange('type', e.target.value)}
              >
                <option value="all">All Types</option>
                <option value="fire">Fire</option>
                <option value="smoke">Smoke</option>
                <option value="fog">Fog</option>
                <option value="smog">Smog</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="filter-date" className="block text-sm font-medium text-gray-700">
                Date Range
              </label>
              <select
                id="filter-date"
                name="filter-date"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                value={filters.dateRange}
                onChange={(e) => handleFilterChange('dateRange', e.target.value)}
              >
                <option value="all">All Time</option>
                <option value="today">Today</option>
                <option value="week">Last 7 Days</option>
                <option value="month">Last 30 Days</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="filter-confidence" className="block text-sm font-medium text-gray-700">
                Confidence Level
              </label>
              <select
                id="filter-confidence"
                name="filter-confidence"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                value={filters.confidence}
                onChange={(e) => handleFilterChange('confidence', e.target.value)}
              >
                <option value="all">All Levels</option>
                <option value="90-100">High (90-100%)</option>
                <option value="70-90">Medium (70-90%)</option>
                <option value="0-70">Low (0-70%)</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      
      {/* Detection List */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Detection Records
          </h3>
        </div>
        
        {loading && detections.length === 0 ? (
          <div className="px-4 py-12 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600 mx-auto"></div>
            <p className="mt-4 text-gray-500">Loading detection records...</p>
          </div>
        ) : mockDetections.length === 0 ? (
          <div className="px-4 py-12 text-center">
            <i className="bi bi-search text-gray-400 text-4xl"></i>
            <p className="mt-4 text-gray-500">No detection records found matching your filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Detection
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Location
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Confidence
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Date & Time
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {mockDetections.map((detection) => (
                  <tr key={detection.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 rounded-md overflow-hidden">
                          <img 
                            src={detection.imageUrl || "https://placehold.co/100x100?text=No+Image"} 
                            alt={`${detection.type} detection`}
                            className="h-10 w-10 object-cover"
                            onError={(e) => {
                              e.target.onerror = null;
                              e.target.src = "https://placehold.co/100x100?text=No+Image";
                            }}
                            crossOrigin="anonymous"
                          />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {detection.type.charAt(0).toUpperCase() + detection.type.slice(1)}
                          </div>
                          <div className="text-sm text-gray-500">
                            ID: {detection.id}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{detection.location?.name || 'Unknown'}</div>
                      <div className="text-xs text-gray-500">
                        {detection.location?.coordinates ? 
                          `${detection.location.coordinates.lat.toFixed(6)}, ${detection.location.coordinates.lng.toFixed(6)}` : 
                          'No coordinates'
                        }
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2 max-w-[100px]">
                          <div 
                            className={`h-2.5 rounded-full ${
                              detection.confidence > 90 ? 'bg-danger-600' : 
                              detection.confidence > 70 ? 'bg-warning-500' : 
                              'bg-success-500'
                            }`} 
                            style={{ width: `${detection.confidence}%` }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-900">{detection.confidence}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(detection.timestamp).toLocaleDateString()}
                      <div className="text-xs">
                        {new Date(detection.timestamp).toLocaleTimeString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        detection.status === 'verified' ? 'bg-success-100 text-success-800' : 
                        detection.status === 'pending' ? 'bg-warning-100 text-warning-800' : 
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {detection.status.charAt(0).toUpperCase() + detection.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button
                          type="button"
                          className="text-primary-600 hover:text-primary-900"
                        >
                          <i className="bi bi-eye"></i>
                        </button>
                        <button
                          type="button"
                          className="text-primary-600 hover:text-primary-900"
                        >
                          <i className="bi bi-download"></i>
                        </button>
                        <button
                          type="button"
                          className="text-danger-600 hover:text-danger-900"
                        >
                          <i className="bi bi-trash"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        
        {/* Load More Button */}
        {hasMore && (
          <div className="px-4 py-3 bg-gray-50 text-center sm:px-6">
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              onClick={loadMore}
              disabled={loading}
            >
              {loading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-gray-700" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Loading...
                </>
              ) : (
                <>
                  <i className="bi bi-arrow-down mr-2"></i>
                  Load More
                </>
              )}
            </button>
          </div>
        )}
      </div>
      
      {/* Footer */}
      <div className="text-center text-sm text-gray-500 mt-8">
        <p>Forest Fire Detection System</p>
      </div>
    </div>
  );
};

export default DetectionHistory;
