import { useState, useEffect, useRef } from 'react';
import { useAlerts } from '../../contexts/AlertContext';

const LiveDetection = () => {
  const { recentAlert } = useAlerts();
  const [isLive, setIsLive] = useState(true);
  const [confidence, setConfidence] = useState(0);
  const [detectionType, setDetectionType] = useState(null);
  const [location, setLocation] = useState(null);
  const [timestamp, setTimestamp] = useState(null);
  const videoRef = useRef(null);
  
  // Simulate video feed and detection
  useEffect(() => {
    // Update detection info when a new alert comes in
    if (recentAlert) {
      setConfidence(recentAlert.confidence || 0);
      setDetectionType(recentAlert.type || null);
      setLocation(recentAlert.location || null);
      setTimestamp(recentAlert.timestamp ? new Date(recentAlert.timestamp) : new Date());
    }
    
    // Simulate random confidence changes for demo purposes
    const interval = setInterval(() => {
      if (isLive) {
        setConfidence(prev => {
          const newValue = prev + (Math.random() * 10 - 5);
          return Math.min(Math.max(newValue, 0), 100);
        });
      }
    }, 3000);
    
    return () => clearInterval(interval);
  }, [recentAlert, isLive]);

  const toggleLiveStatus = () => {
    setIsLive(!isLive);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Live Detection</h1>
        <div className="flex space-x-3">
          <button
            onClick={toggleLiveStatus}
            className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
              isLive ? 'bg-danger-600 hover:bg-danger-700' : 'bg-success-600 hover:bg-success-700'
            } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
          >
            <i className={`bi ${isLive ? 'bi-pause-fill' : 'bi-play-fill'} mr-2`}></i>
            {isLive ? 'Pause Feed' : 'Resume Feed'}
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Video Feed */}
        <div className="lg:col-span-2 bg-white shadow rounded-lg overflow-hidden">
          <div className="px-4 py-5 sm:px-6 flex justify-between items-center border-b border-gray-200">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Drone Camera Feed
            </h3>
            <div className="flex items-center">
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                isLive ? 'bg-success-100 text-success-800' : 'bg-gray-100 text-gray-800'
              }`}>
                <span className={`h-2 w-2 rounded-full ${isLive ? 'bg-success-400' : 'bg-gray-400'} mr-1.5`}></span>
                {isLive ? 'LIVE' : 'PAUSED'}
              </span>
            </div>
          </div>
          <div className="p-4 bg-black h-96 flex items-center justify-center">
            {isLive ? (
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                autoPlay
                muted
                loop
                poster="https://images.unsplash.com/photo-1601058497001-50f6bf8d3f4b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                crossOrigin="anonymous"
              >
                <source src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4" type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            ) : (
              <div className="text-white text-center">
                <i className="bi bi-pause-circle text-5xl mb-2"></i>
                <p>Video feed paused</p>
              </div>
            )}
            
            {/* Detection overlay */}
            {detectionType && isLive && (
              <div className="absolute top-4 left-4 bg-danger-600 bg-opacity-80 text-white px-3 py-1 rounded-md flex items-center">
                <i className={`bi ${
                  detectionType === 'fire' ? 'bi-fire' : 
                  detectionType === 'smoke' ? 'bi-cloud-haze' : 
                  'bi-exclamation-triangle'
                } mr-2`}></i>
                {detectionType.toUpperCase()} DETECTED
              </div>
            )}
          </div>
        </div>
        
        {/* Detection Info */}
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Detection Information
            </h3>
          </div>
          <div className="px-4 py-5 sm:p-6 space-y-6">
            {/* Confidence Meter */}
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Detection Confidence</h4>
              <div className="flex items-center">
                <div className="w-full bg-gray-200 rounded-full h-4 mr-2">
                  <div 
                    className={`h-4 rounded-full ${
                      confidence > 75 ? 'bg-danger-600' : 
                      confidence > 50 ? 'bg-warning-500' : 
                      confidence > 25 ? 'bg-success-500' : 
                      'bg-gray-400'
                    }`} 
                    style={{ width: `${confidence}%` }}
                  ></div>
                </div>
                <span className="text-sm font-medium text-gray-700">{confidence.toFixed(1)}%</span>
              </div>
            </div>
            
            {/* Detection Type */}
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Detection Type</h4>
              <div className="flex items-center">
                <div className={`flex-shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                  detectionType === 'fire' ? 'bg-danger-100' : 
                  detectionType === 'smoke' ? 'bg-warning-100' : 
                  detectionType === 'fog' ? 'bg-primary-100' : 
                  detectionType === 'smog' ? 'bg-purple-100' : 
                  'bg-gray-100'
                }`}>
                  <i className={`bi ${
                    detectionType === 'fire' ? 'bi-fire text-danger-600' : 
                    detectionType === 'smoke' ? 'bi-cloud-haze text-warning-600' : 
                    detectionType === 'fog' ? 'bi-cloud-fog text-primary-600' : 
                    detectionType === 'smog' ? 'bi-cloud text-purple-600' : 
                    'bi-question-circle text-gray-600'
                  } text-lg`}></i>
                </div>
                <span className="ml-3 text-sm font-medium text-gray-900">
                  {detectionType ? detectionType.charAt(0).toUpperCase() + detectionType.slice(1) : 'None detected'}
                </span>
              </div>
            </div>
            
            {/* Location */}
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Location</h4>
              <div className="text-sm text-gray-900">
                {location?.name || 'Unknown location'}
              </div>
              {location?.coordinates && (
                <div className="text-xs text-gray-500 mt-1">
                  Lat: {location.coordinates.lat.toFixed(6)}, Lng: {location.coordinates.lng.toFixed(6)}
                </div>
              )}
            </div>
            
            {/* Timestamp */}
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Timestamp</h4>
              <div className="text-sm text-gray-900">
                {timestamp ? timestamp.toLocaleString() : 'N/A'}
              </div>
            </div>
            
            {/* Actions */}
            <div className="pt-4 border-t border-gray-200">
              <div className="flex space-x-3">
                <button
                  type="button"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-danger-600 hover:bg-danger-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-danger-500"
                >
                  <i className="bi bi-bell mr-2"></i>
                  Alert Authorities
                </button>
                <button
                  type="button"
                  className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  <i className="bi bi-download mr-2"></i>
                  Save Image
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* YOLOv5 Detection Results */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            YOLOv5 Detection Results
          </h3>
        </div>
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="border border-gray-200 rounded-md p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-900">Fire</h4>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  detectionType === 'fire' ? 'bg-danger-100 text-danger-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {detectionType === 'fire' ? 'Detected' : 'Not Detected'}
                </span>
              </div>
              <div className="text-sm text-gray-500">
                Confidence: {detectionType === 'fire' ? `${confidence.toFixed(1)}%` : 'N/A'}
              </div>
            </div>
            
            <div className="border border-gray-200 rounded-md p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-900">Smoke</h4>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  detectionType === 'smoke' ? 'bg-warning-100 text-warning-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {detectionType === 'smoke' ? 'Detected' : 'Not Detected'}
                </span>
              </div>
              <div className="text-sm text-gray-500">
                Confidence: {detectionType === 'smoke' ? `${confidence.toFixed(1)}%` : 'N/A'}
              </div>
            </div>
            
            <div className="border border-gray-200 rounded-md p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-900">Fog</h4>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  detectionType === 'fog' ? 'bg-primary-100 text-primary-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {detectionType === 'fog' ? 'Detected' : 'Not Detected'}
                </span>
              </div>
              <div className="text-sm text-gray-500">
                Confidence: {detectionType === 'fog' ? `${confidence.toFixed(1)}%` : 'N/A'}
              </div>
            </div>
            
            <div className="border border-gray-200 rounded-md p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-sm font-medium text-gray-900">Smog</h4>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                  detectionType === 'smog' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {detectionType === 'smog' ? 'Detected' : 'Not Detected'}
                </span>
              </div>
              <div className="text-sm text-gray-500">
                Confidence: {detectionType === 'smog' ? `${confidence.toFixed(1)}%` : 'N/A'}
              </div>
            </div>
          </div>
          
          <div className="mt-6 border-t border-gray-200 pt-6">
            <h4 className="text-sm font-medium text-gray-900 mb-3">Detection Log</h4>
            <div className="bg-gray-50 rounded-md p-3 text-xs font-mono text-gray-700 h-32 overflow-y-auto">
              <div className="mb-1">[{new Date().toISOString()}] YOLOv5 model loaded successfully</div>
              <div className="mb-1">[{new Date().toISOString()}] Processing frame 1024x768</div>
              <div className="mb-1">[{new Date().toISOString()}] Inference time: 42ms</div>
              {detectionType && (
                <div className="mb-1 text-danger-600">[{new Date().toISOString()}] {detectionType.toUpperCase()} detected with {confidence.toFixed(1)}% confidence</div>
              )}
              <div className="mb-1">[{new Date().toISOString()}] GPS coordinates: {location?.coordinates ? `${location.coordinates.lat.toFixed(6)}, ${location.coordinates.lng.toFixed(6)}` : 'Unknown'}</div>
              <div className="mb-1">[{new Date().toISOString()}] Alert status: {detectionType && confidence > 50 ? 'TRIGGERED' : 'MONITORING'}</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <div className="text-center text-sm text-gray-500 mt-8">
        <p>Forest Fire Detection System</p>
      </div>
    </div>
  );
};

export default LiveDetection;
