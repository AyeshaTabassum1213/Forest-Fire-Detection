import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';

const Settings = () => {
  const { currentUser, userRole } = useAuth();
  const [activeTab, setActiveTab] = useState('account');
  
  // Account Settings
  const [name, setName] = useState('John Doe');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState('');
  
  // Notification Settings
  const [notifications, setNotifications] = useState({
    email: true,
    sms: false,
    push: true,
    telegram: false,
  });
  
  // System Settings
  const [systemSettings, setSystemSettings] = useState({
    detectionThreshold: 70,
    autoAlert: true,
    saveImages: true,
    darkMode: false,
  });
  
  // Drone Settings
  const [droneSettings, setDroneSettings] = useState({
    autoReturn: true,
    maxAltitude: 120,
    maxDistance: 500,
    lowBatteryReturn: 30,
  });
  
  const handleNotificationChange = (type) => {
    setNotifications(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };
  
  const handleSystemSettingChange = (setting, value) => {
    setSystemSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };
  
  const handleDroneSettingChange = (setting, value) => {
    setDroneSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };
  
  const saveSettings = (type) => {
    // In a real app, this would save settings to the backend
    alert(`${type} settings saved successfully!`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Settings</h1>
      </div>
      
      {/* Settings Tabs */}
      <div className="bg-white shadow rounded-lg">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8 px-6" aria-label="Tabs">
            <button
              onClick={() => setActiveTab('account')}
              className={`${
                activeTab === 'account'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <i className={`bi bi-person ${activeTab === 'account' ? 'text-primary-600' : 'text-gray-400'} mr-2`}></i>
              Account
            </button>
            
            <button
              onClick={() => setActiveTab('notifications')}
              className={`${
                activeTab === 'notifications'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <i className={`bi bi-bell ${activeTab === 'notifications' ? 'text-primary-600' : 'text-gray-400'} mr-2`}></i>
              Notifications
            </button>
            
            <button
              onClick={() => setActiveTab('system')}
              className={`${
                activeTab === 'system'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <i className={`bi bi-gear ${activeTab === 'system' ? 'text-primary-600' : 'text-gray-400'} mr-2`}></i>
              System
            </button>
            
            <button
              onClick={() => setActiveTab('drone')}
              className={`${
                activeTab === 'drone'
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              <i className={`bi bi-camera-video ${activeTab === 'drone' ? 'text-primary-600' : 'text-gray-400'} mr-2`}></i>
              Drone
            </button>
            
            {userRole === 'admin' && (
              <button
                onClick={() => setActiveTab('api')}
                className={`${
                  activeTab === 'api'
                    ? 'border-primary-500 text-primary-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
              >
                <i className={`bi bi-code-slash ${activeTab === 'api' ? 'text-primary-600' : 'text-gray-400'} mr-2`}></i>
                API
              </button>
            )}
          </nav>
        </div>
        
        {/* Account Settings */}
        {activeTab === 'account' && (
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Account Settings
            </h3>
            
            <div className="space-y-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="h-16 w-16 rounded-full bg-primary-100 flex items-center justify-center">
                    <i className="bi bi-person text-primary-600 text-2xl"></i>
                  </div>
                </div>
                <div className="ml-5">
                  <button
                    type="button"
                    className="bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  >
                    Change avatar
                  </button>
                  <button
                    type="button"
                    className="ml-3 bg-white py-2 px-3 border border-gray-300 rounded-md shadow-sm text-sm leading-4 font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  >
                    Remove
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Full Name
                  </label>
                  <div className="mt-1">
                    <input
                      type="text"
                      name="name"
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="sm:col-span-3">
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email Address
                  </label>
                  <div className="mt-1">
                    <input
                      type="email"
                      name="email"
                      id="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="sm:col-span-3">
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    Phone Number
                  </label>
                  <div className="mt-1">
                    <input
                      type="tel"
                      name="phone"
                      id="phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="sm:col-span-3">
                  <label htmlFor="role" className="block text-sm font-medium text-gray-700">
                    Role
                  </label>
                  <div className="mt-1">
                    <input
                      type="text"
                      name="role"
                      id="role"
                      value={userRole || 'User'}
                      disabled
                      className="shadow-sm bg-gray-50 block w-full sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Change Password</h4>
                <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                  <div className="sm:col-span-3">
                    <label htmlFor="current-password" className="block text-sm font-medium text-gray-700">
                      Current Password
                    </label>
                    <div className="mt-1">
                      <input
                        type="password"
                        name="current-password"
                        id="current-password"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                    </div>
                  </div>
                  
                  <div className="sm:col-span-3">
                    <label htmlFor="new-password" className="block text-sm font-medium text-gray-700">
                      New Password
                    </label>
                    <div className="mt-1">
                      <input
                        type="password"
                        name="new-password"
                        id="new-password"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                    </div>
                  </div>
                  
                  <div className="sm:col-span-3">
                    <label htmlFor="confirm-password" className="block text-sm font-medium text-gray-700">
                      Confirm New Password
                    </label>
                    <div className="mt-1">
                      <input
                        type="password"
                        name="confirm-password"
                        id="confirm-password"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => saveSettings('Account')}
                  className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Notification Settings */}
        {activeTab === 'notifications' && (
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Notification Settings
            </h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">Notification Methods</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="bi bi-envelope text-gray-400 text-xl mr-3"></i>
                      <div>
                        <p className="text-sm font-medium text-gray-700">Email Notifications</p>
                        <p className="text-xs text-gray-500">Receive alerts and reports via email</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleNotificationChange('email')}
                        className={`${
                          notifications.email ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={notifications.email}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            notifications.email ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="bi bi-chat-dots text-gray-400 text-xl mr-3"></i>
                      <div>
                        <p className="text-sm font-medium text-gray-700">SMS Notifications</p>
                        <p className="text-xs text-gray-500">Receive alerts via text message</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleNotificationChange('sms')}
                        className={`${
                          notifications.sms ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={notifications.sms}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            notifications.sms ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="bi bi-bell text-gray-400 text-xl mr-3"></i>
                      <div>
                        <p className="text-sm font-medium text-gray-700">Push Notifications</p>
                        <p className="text-xs text-gray-500">Receive alerts on your device</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleNotificationChange('push')}
                        className={`${
                          notifications.push ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={notifications.push}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            notifications.push ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <i className="bi bi-telegram text-gray-400 text-xl mr-3"></i>
                      <div>
                        <p className="text-sm font-medium text-gray-700">Telegram Notifications</p>
                        <p className="text-xs text-gray-500">Receive alerts via Telegram</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleNotificationChange('telegram')}
                        className={`${
                          notifications.telegram ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={notifications.telegram}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            notifications.telegram ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Notification Preferences</h4>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="fire-alerts"
                        name="fire-alerts"
                        type="checkbox"
                        defaultChecked
                        className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label htmlFor="fire-alerts" className="font-medium text-gray-700">
                        Fire Alerts
                      </label>
                      <p className="text-gray-500">Receive notifications for fire detections</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="smoke-alerts"
                        name="smoke-alerts"
                        type="checkbox"
                        defaultChecked
                        className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label htmlFor="smoke-alerts" className="font-medium text-gray-700">
                        Smoke Alerts
                      </label>
                      <p className="text-gray-500">Receive notifications for smoke detections</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="system-alerts"
                        name="system-alerts"
                        type="checkbox"
                        defaultChecked
                        className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label htmlFor="system-alerts" className="font-medium text-gray-700">
                        System Alerts
                      </label>
                      <p className="text-gray-500">Receive notifications for system status changes</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="report-notifications"
                        name="report-notifications"
                        type="checkbox"
                        defaultChecked
                        className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label htmlFor="report-notifications" className="font-medium text-gray-700">
                        Report Notifications
                      </label>
                      <p className="text-gray-500">Receive notifications when reports are generated</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => saveSettings('Notification')}
                  className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* System Settings */}
        {activeTab === 'system' && (
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              System Settings
            </h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">Detection Settings</h4>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="detection-threshold" className="block text-sm font-medium text-gray-700">
                      Detection Confidence Threshold ({systemSettings.detectionThreshold}%)
                    </label>
                    <div className="mt-1 flex items-center">
                      <input
                        type="range"
                        id="detection-threshold"
                        name="detection-threshold"
                        min="0"
                        max="100"
                        value={systemSettings.detectionThreshold}
                        onChange={(e) => handleSystemSettingChange('detectionThreshold', parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      Minimum confidence level required to trigger an alert
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Automatic Alerts</p>
                      <p className="text-xs text-gray-500">Automatically send alerts when detections exceed threshold</p>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleSystemSettingChange('autoAlert', !systemSettings.autoAlert)}
                        className={`${
                          systemSettings.autoAlert ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={systemSettings.autoAlert}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            systemSettings.autoAlert ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Save Detection Images</p>
                      <p className="text-xs text-gray-500">Save images of detected fires and smoke</p>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleSystemSettingChange('saveImages', !systemSettings.saveImages)}
                        className={`${
                          systemSettings.saveImages ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={systemSettings.saveImages}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            systemSettings.saveImages ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Interface Settings</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Dark Mode</p>
                      <p className="text-xs text-gray-500">Use dark theme for the interface</p>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleSystemSettingChange('darkMode', !systemSettings.darkMode)}
                        className={`${
                          systemSettings.darkMode ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={systemSettings.darkMode}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            systemSettings.darkMode ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="language" className="block text-sm font-medium text-gray-700">
                      Language
                    </label>
                    <select
                      id="language"
                      name="language"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="english"
                    >
                      <option value="english">English</option>
                      <option value="spanish">Spanish</option>
                      <option value="french">French</option>
                      <option value="german">German</option>
                      <option value="chinese">Chinese</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="timezone" className="block text-sm font-medium text-gray-700">
                      Timezone
                    </label>
                    <select
                      id="timezone"
                      name="timezone"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="utc"
                    >
                      <option value="utc">UTC</option>
                      <option value="est">Eastern Time (EST)</option>
                      <option value="cst">Central Time (CST)</option>
                      <option value="mst">Mountain Time (MST)</option>
                      <option value="pst">Pacific Time (PST)</option>
                    </select>
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Data Management</h4>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="data-retention" className="block text-sm font-medium text-gray-700">
                      Data Retention Period
                    </label>
                    <select
                      id="data-retention"
                      name="data-retention"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="90"
                    >
                      <option value="30">30 days</option>
                      <option value="60">60 days</option>
                      <option value="90">90 days</option>
                      <option value="180">180 days</option>
                      <option value="365">1 year</option>
                      <option value="forever">Forever</option>
                    </select>
                    <p className="mt-1 text-xs text-gray-500">
                      How long to keep detection data before automatic deletion
                    </p>
                  </div>
                  
                  <div className="flex justify-between">
                    <button
                      type="button"
                      className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    >
                      Export All Data
                    </button>
                    
                    <button
                      type="button"
                      className="inline-flex items-center px-3 py-2 border border-danger-300 shadow-sm text-sm leading-4 font-medium rounded-md text-danger-700 bg-white hover:bg-danger-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-danger-500"
                    >
                      Clear All Data
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => saveSettings('System')}
                  className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Drone Settings */}
        {activeTab === 'drone' && (
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Drone Settings
            </h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">Flight Settings</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Automatic Return to Home</p>
                      <p className="text-xs text-gray-500">Automatically return to launch point when mission complete</p>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        onClick={() => handleDroneSettingChange('autoReturn', !droneSettings.autoReturn)}
                        className={`${
                          droneSettings.autoReturn ? 'bg-primary-600' : 'bg-gray-200'
                        } relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500`}
                        role="switch"
                        aria-checked={droneSettings.autoReturn}
                      >
                        <span
                          aria-hidden="true"
                          className={`${
                            droneSettings.autoReturn ? 'translate-x-5' : 'translate-x-0'
                          } pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200`}
                        ></span>
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label htmlFor="max-altitude" className="block text-sm font-medium text-gray-700">
                      Maximum Altitude ({droneSettings.maxAltitude} meters)
                    </label>
                    <div className="mt-1 flex items-center">
                      <input
                        type="range"
                        id="max-altitude"
                        name="max-altitude"
                        min="10"
                        max="500"
                        value={droneSettings.maxAltitude}
                        onChange={(e) => handleDroneSettingChange('maxAltitude', parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      Maximum flying altitude in meters
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="max-distance" className="block text-sm font-medium text-gray-700">
                      Maximum Distance ({droneSettings.maxDistance} meters)
                    </label>
                    <div className="mt-1 flex items-center">
                      <input
                        type="range"
                        id="max-distance"
                        name="max-distance"
                        min="100"
                        max="2000"
                        value={droneSettings.maxDistance}
                        onChange={(e) => handleDroneSettingChange('maxDistance', parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      Maximum distance from home point in meters
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="low-battery" className="block text-sm font-medium text-gray-700">
                      Low Battery Return ({droneSettings.lowBatteryReturn}%)
                    </label>
                    <div className="mt-1 flex items-center">
                      <input
                        type="range"
                        id="low-battery"
                        name="low-battery"
                        min="10"
                        max="50"
                        value={droneSettings.lowBatteryReturn}
                        onChange={(e) => handleDroneSettingChange('lowBatteryReturn', parseInt(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      Battery percentage at which drone will automatically return to home
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Camera Settings</h4>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="camera-resolution" className="block text-sm font-medium text-gray-700">
                      Camera Resolution
                    </label>
                    <select
                      id="camera-resolution"
                      name="camera-resolution"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="1080p"
                    >
                      <option value="720p">720p HD</option>
                      <option value="1080p">1080p Full HD</option>
                      <option value="2.7k">2.7K</option>
                      <option value="4k">4K Ultra HD</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="frame-rate" className="block text-sm font-medium text-gray-700">
                      Frame Rate
                    </label>
                    <select
                      id="frame-rate"
                      name="frame-rate"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="30"
                    >
                      <option value="24">24 fps</option>
                      <option value="30">30 fps</option>
                      <option value="60">60 fps</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Thermal Imaging</p>
                      <p className="text-xs text-gray-500">Enable thermal imaging camera</p>
                    </div>
                    <div className="flex items-center">
                      <button
                        type="button"
                        className="bg-primary-600 relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                        role="switch"
                        aria-checked="true"
                      >
                        <span
                          aria-hidden="true"
                          className="translate-x-5 pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200"
                        ></span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Patrol Settings</h4>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="patrol-mode" className="block text-sm font-medium text-gray-700">
                      Patrol Mode
                    </label>
                    <select
                      id="patrol-mode"
                      name="patrol-mode"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="waypoint"
                    >
                      <option value="waypoint">Waypoint Mission</option>
                      <option value="grid">Grid Pattern</option>
                      <option value="perimeter">Perimeter Patrol</option>
                      <option value="manual">Manual Control</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="patrol-speed" className="block text-sm font-medium text-gray-700">
                      Patrol Speed
                    </label>
                    <select
                      id="patrol-speed"
                      name="patrol-speed"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="medium"
                    >
                      <option value="slow">Slow (5 km/h)</option>
                      <option value="medium">Medium (15 km/h)</option>
                      <option value="fast">Fast (25 km/h)</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="patrol-interval" className="block text-sm font-medium text-gray-700">
                      Patrol Interval
                    </label>
                    <select
                      id="patrol-interval"
                      name="patrol-interval"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="60"
                    >
                      <option value="30">30 minutes</option>
                      <option value="60">1 hour</option>
                      <option value="120">2 hours</option>
                      <option value="240">4 hours</option>
                      <option value="360">6 hours</option>
                    </select>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => saveSettings('Drone')}
                  className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* API Settings */}
        {activeTab === 'api' && userRole === 'admin' && (
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              API Settings
            </h3>
            
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-3">API Keys</h4>
                <div className="bg-gray-50 p-4 rounded-md">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Production API Key</p>
                      <p className="text-xs text-gray-500 mt-1">Use this key for production environments</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="bg-white px-3 py-1 rounded border border-gray-300 text-sm font-mono">
                        ••••••••••••••••
                      </div>
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-eye"></i>
                      </button>
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-arrow-repeat"></i>
                      </button>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Development API Key</p>
                      <p className="text-xs text-gray-500 mt-1">Use this key for testing and development</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="bg-white px-3 py-1 rounded border border-gray-300 text-sm font-mono">
                        ••••••••••••••••
                      </div>
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-eye"></i>
                      </button>
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-arrow-repeat"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">Webhook Configuration</h4>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="webhook-url" className="block text-sm font-medium text-gray-700">
                      Webhook URL
                    </label>
                    <div className="mt-1">
                      <input
                        type="text"
                        name="webhook-url"
                        id="webhook-url"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        placeholder="https://example.com/webhook"
                      />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      URL to receive detection events
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="webhook-secret" className="block text-sm font-medium text-gray-700">
                      Webhook Secret
                    </label>
                    <div className="mt-1">
                      <input
                        type="password"
                        name="webhook-secret"
                        id="webhook-secret"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        placeholder="••••••••••••••••"
                      />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      Secret key used to sign webhook payloads
                    </p>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="webhook-enabled"
                        name="webhook-enabled"
                        type="checkbox"
                        className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label htmlFor="webhook-enabled" className="font-medium text-gray-700">
                        Enable Webhooks
                      </label>
                      <p className="text-gray-500">Send detection events to the webhook URL</p>
                    </div>
                  </div>
                  
                  <div>
                    <button
                      type="button"
                      className="inline-flex items-center px-3 py-2 border border-gray-300 shadow-sm text-sm leading-4 font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    >
                      Test Webhook
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="pt-5 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-3">API Access Control</h4>
                <div className="space-y-4">
                  <div>
                    <label htmlFor="allowed-origins" className="block text-sm font-medium text-gray-700">
                      Allowed Origins (CORS)
                    </label>
                    <div className="mt-1">
                      <input
                        type="text"
                        name="allowed-origins"
                        id="allowed-origins"
                        className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        placeholder="https://example.com, https://app.example.com"
                      />
                    </div>
                    <p className="mt-1 text-xs text-gray-500">
                      Comma-separated list of domains allowed to access the API
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="rate-limit" className="block text-sm font-medium text-gray-700">
                      Rate Limit
                    </label>
                    <select
                      id="rate-limit"
                      name="rate-limit"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                      defaultValue="100"
                    >
                      <option value="10">10 requests/minute</option>
                      <option value="50">50 requests/minute</option>
                      <option value="100">100 requests/minute</option>
                      <option value="500">500 requests/minute</option>
                      <option value="1000">1000 requests/minute</option>
                    </select>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex items-center h-5">
                      <input
                        id="require-auth"
                        name="require-auth"
                        type="checkbox"
                        defaultChecked
                        className="focus:ring-primary-500 h-4 w-4 text-primary-600 border-gray-300 rounded"
                      />
                    </div>
                    <div className="ml-3 text-sm">
                      <label htmlFor="require-auth" className="font-medium text-gray-700">
                        Require Authentication
                      </label>
                      <p className="text-gray-500">Require API key for all requests</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button
                  type="button"
                  className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={() => saveSettings('API')}
                  className="ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* Footer */}
      <div className="text-center text-sm text-gray-500 mt-8">
        <p>Forest Fire Detection System</p>
      </div>
    </div>
  );
};

export default Settings;
