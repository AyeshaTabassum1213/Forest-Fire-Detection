import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useAlerts } from '../../contexts/AlertContext';
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { db, storageRef } from '../../firebase';
import { ref, getDownloadURL } from 'firebase/storage';
import { Line, Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, Title } from 'chart.js';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, Title);

const Dashboard = () => {
  const { userRole } = useAuth();
  const { alerts } = useAlerts();
  const [stats, setStats] = useState({
    totalDetections: 0,
    fireDetections: 0,
    smokeDetections: 0,
    fogDetections: 0,
    smogDetections: 0,
  });
  const [recentDetections, setRecentDetections] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch dashboard data
  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        // Get recent detections
        const detectionsRef = collection(db, 'detections');
        const detectionsQuery = query(
          detectionsRef,
          orderBy('timestamp', 'desc'),
          limit(5)
        );
        
        const detectionsSnapshot = await getDocs(detectionsQuery);
        const detectionsList = detectionsSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        
        setRecentDetections(detectionsList);
        
        // Calculate stats
        const totalDetections = alerts.length;
        const fireDetections = alerts.filter(alert => alert.type === 'fire').length;
        const smokeDetections = alerts.filter(alert => alert.type === 'smoke').length;
        const fogDetections = alerts.filter(alert => alert.type === 'fog').length;
        const smogDetections = alerts.filter(alert => alert.type === 'smog').length;
        
        setStats({
          totalDetections,
          fireDetections,
          smokeDetections,
          fogDetections,
          smogDetections
        });
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, [alerts]);

  // Chart data for detection types
  const detectionTypeData = {
    labels: ['Fire', 'Smoke', 'Fog', 'Smog'],
    datasets: [
      {
        data: [stats.fireDetections, stats.smokeDetections, stats.fogDetections, stats.smogDetections],
        backgroundColor: [
          '#ef4444',
          '#f59e0b',
          '#3b82f6',
          '#8b5cf6',
        ],
        borderWidth: 1,
      },
    ],
  };

  // Chart data for detections over time
  const timelineData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
    datasets: [
      {
        label: 'Fire Detections',
        data: [12, 19, 3, 5, 2, 3, 7],
        borderColor: '#ef4444',
        backgroundColor: 'rgba(239, 68, 68, 0.2)',
        tension: 0.4,
      },
      {
        label: 'Smoke Detections',
        data: [7, 11, 5, 8, 3, 7, 9],
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.2)',
        tension: 0.4,
      },
    ],
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">Dashboard</h1>
        <div className="flex space-x-3">
          <Link
            to="/live-detection"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <i className="bi bi-camera-video mr-2"></i>
            Live Detection
          </Link>
          <Link
            to="/map"
            className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 dark:text-gray-300 bg-white dark:bg-dark-200 hover:bg-gray-50 dark:hover:bg-dark-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <i className="bi bi-map mr-2"></i>
            View Map
          </Link>
        </div>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white dark:bg-dark-200 overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-primary-100 dark:bg-primary-900/30 rounded-md p-3">
                <i className="bi bi-camera text-primary-600 dark:text-primary-400 text-xl"></i>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                    Total Detections
                  </dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900 dark:text-gray-100">
                      {stats.totalDetections}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-dark-200 overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-danger-100 dark:bg-danger-900/30 rounded-md p-3">
                <i className="bi bi-fire text-danger-600 dark:text-danger-400 text-xl"></i>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                    Fire Detections
                  </dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900 dark:text-gray-100">
                      {stats.fireDetections}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-dark-200 overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-warning-100 dark:bg-warning-900/30 rounded-md p-3">
                <i className="bi bi-cloud-haze text-warning-600 dark:text-warning-400 text-xl"></i>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                    Smoke Detections
                  </dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900 dark:text-gray-100">
                      {stats.smokeDetections}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-dark-200 overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0 bg-success-100 dark:bg-success-900/30 rounded-md p-3">
                <i className="bi bi-check-circle text-success-600 dark:text-success-400 text-xl"></i>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 dark:text-gray-400 truncate">
                    System Status
                  </dt>
                  <dd>
                    <div className="text-lg font-medium text-gray-900 dark:text-gray-100">
                      Operational
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
        <div className="bg-white dark:bg-dark-200 overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100 mb-4">
              Detection Types
            </h3>
            <div className="h-64">
              <Doughnut 
                data={detectionTypeData} 
                options={{
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'bottom',
                      labels: {
                        color: '#6b7280' // gray-500 for light mode
                      }
                    },
                  },
                }}
              />
            </div>
          </div>
        </div>
        
        <div className="bg-white dark:bg-dark-200 overflow-hidden shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100 mb-4">
              Detections Over Time
            </h3>
            <div className="h-64">
              <Line 
                data={timelineData} 
                options={{
                  maintainAspectRatio: false,
                  plugins: {
                    legend: {
                      position: 'bottom',
                      labels: {
                        color: '#6b7280' // gray-500 for light mode
                      }
                    },
                  },
                  scales: {
                    y: {
                      beginAtZero: true,
                      grid: {
                        color: '#e5e7eb' // gray-200 for light mode
                      },
                      ticks: {
                        color: '#6b7280' // gray-500 for light mode
                      }
                    },
                    x: {
                      grid: {
                        color: '#e5e7eb' // gray-200 for light mode
                      },
                      ticks: {
                        color: '#6b7280' // gray-500 for light mode
                      }
                    }
                  },
                }}
              />
            </div>
          </div>
        </div>
      </div>
      
      {/* Recent Detections */}
      <div className="bg-white dark:bg-dark-200 shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100">
            Recent Detections
          </h3>
          <Link
            to="/history"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <i className="bi bi-clock-history mr-2"></i>
            View History
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50 dark:bg-dark-300">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Image</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Confidence</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recentDetections.length > 0 ? (
                recentDetections.map((detection) => (
                  <tr key={detection.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {detection.imageUrl ? (
                        <img 
                          src={detection.imageUrl} 
                          alt="Detection" 
                          className="w-20 h-20 object-cover rounded-lg"
                          onError={(e) => {
                            e.target.style.display = 'none';
                          }}
                        />
                      ) : (
                        <div className="w-20 h-20 flex items-center justify-center bg-gray-100 dark:bg-dark-300 rounded-lg">
                          <i className="bi bi-image text-gray-400"></i>
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className={`flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center ${
                          detection.type === 'fire' ? 'bg-danger-100' : 
                          detection.type === 'smoke' ? 'bg-warning-100' : 
                          detection.type === 'fog' ? 'bg-primary-100' : 
                          'bg-purple-100'
                        }`}>
                          <i className={`bi ${
                            detection.type === 'fire' ? 'bi-fire text-danger-600' : 
                            detection.type === 'smoke' ? 'bi-cloud-haze text-warning-600' : 
                            detection.type === 'fog' ? 'bi-cloud-fog text-primary-600' : 
                            'bi-cloud text-purple-600'
                          } text-lg`}></i>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {detection.type.charAt(0).toUpperCase() + detection.type.slice(1)}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{detection.location?.name || 'Unknown'}</div>
                      <div className="text-xs text-gray-500">
                        {detection.location?.coordinates ? 
                          `${detection.location.coordinates.lat.toFixed(6)}, ${detection.location.coordinates.lng.toFixed(6)}` : 
                          'No coordinates'
                        }
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{detection.confidence || 0}%</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {detection.timestamp ? new Date(detection.timestamp).toLocaleString() : 'Unknown'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        detection.status === 'verified' ? 'bg-success-100 text-success-800' : 
                        detection.status === 'pending' ? 'bg-warning-100 text-warning-800' : 
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {detection.status ? detection.status.charAt(0).toUpperCase() + detection.status.slice(1) : 'Unknown'}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="px-6 py-4 text-center text-sm text-gray-500">
                    No recent detections found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* System Status */}
      <div className="bg-white dark:bg-dark-200 shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 dark:text-gray-100">
            System Status
          </h3>
        </div>
        <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <i className="bi bi-cpu text-primary-600 text-xl"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">Raspberry Pi</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  <span className="inline-flex items-center">
                    <span className="h-2 w-2 rounded-full bg-success-500 mr-1.5"></span>
                    Online
                  </span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <i className="bi bi-camera-video text-primary-600 text-xl"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">Drone Camera</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  <span className="inline-flex items-center">
                    <span className="h-2 w-2 rounded-full bg-success-500 mr-1.5"></span>
                    Operational
                  </span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <i className="bi bi-cloud-upload text-primary-600 text-xl"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">Cloud Storage</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  <span className="inline-flex items-center">
                    <span className="h-2 w-2 rounded-full bg-success-500 mr-1.5"></span>
                    Connected
                  </span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <i className="bi bi-battery-full text-primary-600 text-xl"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">Drone Battery</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  <span className="inline-flex items-center">
                    <span className="h-2 w-2 rounded-full bg-warning-500 mr-1.5"></span>
                    78%
                  </span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <i className="bi bi-wifi text-primary-600 text-xl"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">Network</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  <span className="inline-flex items-center">
                    <span className="h-2 w-2 rounded-full bg-success-500 mr-1.5"></span>
                    Strong
                  </span>
                </p>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <i className="bi bi-geo-alt text-primary-600 text-xl"></i>
              </div>
              <div className="ml-3">
                <h4 className="text-sm font-medium text-gray-900 dark:text-gray-100">GPS Signal</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  <span className="inline-flex items-center">
                    <span className="h-2 w-2 rounded-full bg-success-500 mr-1.5"></span>
                    Locked
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <div className="text-center text-sm text-gray-500 dark:text-gray-400 mt-8">
        <p>Forest Fire Detection System</p>
      </div>
    </div>
  );
};

export default Dashboard;