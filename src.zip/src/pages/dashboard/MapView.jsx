import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import { useAlerts } from '../../contexts/AlertContext';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for Leaflet marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

// Custom icons
const fireIcon = new L.Icon({
  iconUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-icon.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-shadow.png',
  shadowSize: [41, 41],
  className: 'fire-marker', // We'll style this with CSS
});

const smokeIcon = new L.Icon({
  iconUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-icon.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-shadow.png',
  shadowSize: [41, 41],
  className: 'smoke-marker', // We'll style this with CSS
});

const droneIcon = new L.Icon({
  iconUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-icon.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowUrl: 'https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/images/marker-shadow.png',
  shadowSize: [41, 41],
  className: 'drone-marker', // We'll style this with CSS
});

const MapView = () => {
  const { alerts } = useAlerts();
  const [mapCenter, setMapCenter] = useState([37.7749, -122.4194]); // Default: San Francisco
  const [dronePosition, setDronePosition] = useState([37.7749, -122.4194]);
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [mapLayers, setMapLayers] = useState({
    fires: true,
    smoke: true,
    drone: true,
    heatmap: false,
  });
  
  // Simulate drone movement
  useEffect(() => {
    const interval = setInterval(() => {
      setDronePosition(prev => [
        prev[0] + (Math.random() * 0.002 - 0.001),
        prev[1] + (Math.random() * 0.002 - 0.001),
      ]);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Process alerts for map display
  const mapAlerts = alerts.filter(alert => {
    if (!alert.location?.coordinates) return false;
    if (alert.type === 'fire' && !mapLayers.fires) return false;
    if (alert.type === 'smoke' && !mapLayers.smoke) return false;
    return true;
  });
  
  const toggleLayer = (layer) => {
    setMapLayers(prev => ({
      ...prev,
      [layer]: !prev[layer]
    }));
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Map View</h1>
        <div className="flex space-x-3">
          <button
            onClick={() => setMapCenter(dronePosition)}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <i className="bi bi-geo-alt mr-2"></i>
            Center on Drone
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Map Controls */}
        <div className="bg-white shadow rounded-lg overflow-hidden">
          <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Map Controls
            </h3>
          </div>
          <div className="px-4 py-5 sm:p-6 space-y-4">
            <div>
              <h4 className="text-sm font-medium text-gray-700 mb-2">Layers</h4>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input
                    id="layer-fires"
                    name="layer-fires"
                    type="checkbox"
                    checked={mapLayers.fires}
                    onChange={() => toggleLayer('fires')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="layer-fires" className="ml-2 block text-sm text-gray-900">
                    Fire Detections
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="layer-smoke"
                    name="layer-smoke"
                    type="checkbox"
                    checked={mapLayers.smoke}
                    onChange={() => toggleLayer('smoke')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="layer-smoke" className="ml-2 block text-sm text-gray-900">
                    Smoke Detections
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="layer-drone"
                    name="layer-drone"
                    type="checkbox"
                    checked={mapLayers.drone}
                    onChange={() => toggleLayer('drone')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="layer-drone" className="ml-2 block text-sm text-gray-900">
                    Drone Position
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    id="layer-heatmap"
                    name="layer-heatmap"
                    type="checkbox"
                    checked={mapLayers.heatmap}
                    onChange={() => toggleLayer('heatmap')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
                  />
                  <label htmlFor="layer-heatmap" className="ml-2 block text-sm text-gray-900">
                    Heat Map
                  </label>
                </div>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200">
              <h4 className="text-sm font-medium text-gray-700 mb-2">Drone Information</h4>
              <div className="text-sm text-gray-500">
                <div className="mb-1">
                  <span className="font-medium text-gray-700">Latitude:</span> {dronePosition[0].toFixed(6)}
                </div>
                <div className="mb-1">
                  <span className="font-medium text-gray-700">Longitude:</span> {dronePosition[1].toFixed(6)}
                </div>
                <div className="mb-1">
                  <span className="font-medium text-gray-700">Altitude:</span> 120m
                </div>
                <div className="mb-1">
                  <span className="font-medium text-gray-700">Speed:</span> 15 km/h
                </div>
                <div className="mb-1">
                  <span className="font-medium text-gray-700">Battery:</span> 78%
                </div>
              </div>
            </div>
            
            {selectedAlert && (
              <div className="pt-4 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Selected Detection</h4>
                <div className="text-sm text-gray-500">
                  <div className="mb-1">
                    <span className="font-medium text-gray-700">Type:</span> {selectedAlert.type.charAt(0).toUpperCase() + selectedAlert.type.slice(1)}
                  </div>
                  <div className="mb-1">
                    <span className="font-medium text-gray-700">Location:</span> {selectedAlert.location?.name || 'Unknown'}
                  </div>
                  <div className="mb-1">
                    <span className="font-medium text-gray-700">Confidence:</span> {selectedAlert.confidence || 0}%
                  </div>
                  <div className="mb-1">
                    <span className="font-medium text-gray-700">Time:</span> {selectedAlert.timestamp ? new Date(selectedAlert.timestamp).toLocaleString() : 'Unknown'}
                  </div>
                  <div className="mt-3">
                    <button
                      type="button"
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                    >
                      <i className="bi bi-eye mr-1"></i>
                      View Details
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        
        {/* Map */}
        <div className="lg:col-span-3 bg-white shadow rounded-lg overflow-hidden">
          <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Forest Fire Detection Map
            </h3>
          </div>
          <div className="h-[600px]">
            <MapContainer 
              center={mapCenter} 
              zoom={13} 
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              
              {/* Drone Marker */}
              {mapLayers.drone && (
                <Marker position={dronePosition} icon={droneIcon}>
                  <Popup>
                    <div>
                      <h3 className="text-sm font-medium text-gray-900">Drone</h3>
                      <p className="text-xs text-gray-500">
                        Lat: {dronePosition[0].toFixed(6)}, Lng: {dronePosition[1].toFixed(6)}
                      </p>
                      <p className="text-xs text-gray-500">
                        Altitude: 120m, Battery: 78%
                      </p>
                    </div>
                  </Popup>
                </Marker>
              )}
              
              {/* Drone Range Circle */}
              {mapLayers.drone && (
                <Circle 
                  center={dronePosition}
                  radius={500}
                  pathOptions={{ color: '#3b82f6', fillColor: '#3b82f6', fillOpacity: 0.1 }}
                />
              )}
              
              {/* Alert Markers */}
              {mapAlerts.map((alert) => {
                if (!alert.location?.coordinates) return null;
                
                const position = [
                  alert.location.coordinates.lat,
                  alert.location.coordinates.lng
                ];
                
                return (
                  <Marker 
                    key={alert.id} 
                    position={position}
                    icon={alert.type === 'fire' ? fireIcon : smokeIcon}
                    eventHandlers={{
                      click: () => {
                        setSelectedAlert(alert);
                      },
                    }}
                  >
                    <Popup>
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">
                          {alert.type.charAt(0).toUpperCase() + alert.type.slice(1)} Detection
                        </h3>
                        <p className="text-xs text-gray-500">
                          Location: {alert.location?.name || 'Unknown'}
                        </p>
                        <p className="text-xs text-gray-500">
                          Confidence: {alert.confidence || 0}%
                        </p>
                        <p className="text-xs text-gray-500">
                          Time: {alert.timestamp ? new Date(alert.timestamp).toLocaleString() : 'Unknown'}
                        </p>
                      </div>
                    </Popup>
                  </Marker>
                );
              })}
            </MapContainer>
          </div>
        </div>
      </div>
      
      {/* Legend */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Map Legend
          </h3>
        </div>
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center">
              <div className="h-6 w-6 rounded-full bg-danger-600 mr-2"></div>
              <span className="text-sm text-gray-700">Fire Detection</span>
            </div>
            <div className="flex items-center">
              <div className="h-6 w-6 rounded-full bg-warning-500 mr-2"></div>
              <span className="text-sm text-gray-700">Smoke Detection</span>
            </div>
            <div className="flex items-center">
              <div className="h-6 w-6 rounded-full bg-primary-600 mr-2"></div>
              <span className="text-sm text-gray-700">Drone Position</span>
            </div>
            <div className="flex items-center">
              <div className="h-6 w-6 rounded-full bg-primary-200 border border-primary-600 mr-2"></div>
              <span className="text-sm text-gray-700">Drone Range (500m)</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <div className="text-center text-sm text-gray-500 mt-8">
        <p>Forest Fire Detection System</p>
      </div>
    </div>
  );
};

export default MapView;
