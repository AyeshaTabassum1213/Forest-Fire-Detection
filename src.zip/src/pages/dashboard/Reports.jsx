import { useState } from 'react';
import { Bar, Line, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title } from 'chart.js';

// Register ChartJS components
ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title);

const Reports = () => {
  const [reportType, setReportType] = useState('summary');
  const [dateRange, setDateRange] = useState('month');
  const [exportFormat, setExportFormat] = useState('pdf');
  
  // Mock data for charts
  const detectionsByTypeData = {
    labels: ['Fire', 'Smoke', 'Fog', 'Smog'],
    datasets: [
      {
        data: [65, 42, 18, 7],
        backgroundColor: [
          '#ef4444',
          '#f59e0b',
          '#3b82f6',
          '#8b5cf6',
        ],
        borderWidth: 1,
      },
    ],
  };
  
  const detectionsByTimeData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Fire Detections',
        data: [12, 19, 3, 5, 2, 3, 7, 8, 10, 15, 9, 4],
        borderColor: '#ef4444',
        backgroundColor: 'rgba(239, 68, 68, 0.2)',
        tension: 0.4,
      },
      {
        label: 'Smoke Detections',
        data: [7, 11, 5, 8, 3, 7, 9, 12, 8, 5, 3, 6],
        borderColor: '#f59e0b',
        backgroundColor: 'rgba(245, 158, 11, 0.2)',
        tension: 0.4,
      },
    ],
  };
  
  const detectionsByLocationData = {
    labels: ['North Ridge', 'Eagle Peak', 'Redwood Valley', 'Misty Mountains', 'Pine Forest'],
    datasets: [
      {
        label: 'Detections by Location',
        data: [25, 18, 30, 12, 15],
        backgroundColor: [
          'rgba(239, 68, 68, 0.7)',
          'rgba(245, 158, 11, 0.7)',
          'rgba(59, 130, 246, 0.7)',
          'rgba(139, 92, 246, 0.7)',
          'rgba(16, 185, 129, 0.7)',
        ],
        borderColor: [
          'rgba(239, 68, 68, 1)',
          'rgba(245, 158, 11, 1)',
          'rgba(59, 130, 246, 1)',
          'rgba(139, 92, 246, 1)',
          'rgba(16, 185, 129, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };
  
  const confidenceLevelsData = {
    labels: ['90-100%', '80-90%', '70-80%', '60-70%', 'Below 60%'],
    datasets: [
      {
        label: 'Detections by Confidence',
        data: [42, 28, 15, 8, 7],
        backgroundColor: 'rgba(59, 130, 246, 0.5)',
        borderColor: 'rgba(59, 130, 246, 1)',
        borderWidth: 1,
      },
    ],
  };
  
  const generateReport = () => {
    // In a real app, this would generate and download a report
    alert(`Generating ${reportType} report for ${dateRange} in ${exportFormat} format`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Reports</h1>
        <div className="flex space-x-3">
          <button
            type="button"
            onClick={generateReport}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            <i className="bi bi-file-earmark-arrow-down mr-2"></i>
            Generate Report
          </button>
        </div>
      </div>
      
      {/* Report Configuration */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Report Configuration
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <div>
              <label htmlFor="report-type" className="block text-sm font-medium text-gray-700">
                Report Type
              </label>
              <select
                id="report-type"
                name="report-type"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
              >
                <option value="summary">Summary Report</option>
                <option value="detailed">Detailed Report</option>
                <option value="location">Location-based Report</option>
                <option value="trend">Trend Analysis</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="date-range" className="block text-sm font-medium text-gray-700">
                Date Range
              </label>
              <select
                id="date-range"
                name="date-range"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
              >
                <option value="week">Last 7 Days</option>
                <option value="month">Last 30 Days</option>
                <option value="quarter">Last 3 Months</option>
                <option value="year">Last 12 Months</option>
                <option value="custom">Custom Range</option>
              </select>
            </div>
            
            <div>
              <label htmlFor="export-format" className="block text-sm font-medium text-gray-700">
                Export Format
              </label>
              <select
                id="export-format"
                name="export-format"
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                value={exportFormat}
                onChange={(e) => setExportFormat(e.target.value)}
              >
                <option value="pdf">PDF</option>
                <option value="excel">Excel</option>
                <option value="csv">CSV</option>
                <option value="json">JSON</option>
              </select>
            </div>
          </div>
          
          {dateRange === 'custom' && (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 mt-4">
              <div>
                <label htmlFor="start-date" className="block text-sm font-medium text-gray-700">
                  Start Date
                </label>
                <input
                  type="date"
                  name="start-date"
                  id="start-date"
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                />
              </div>
              <div>
                <label htmlFor="end-date" className="block text-sm font-medium text-gray-700">
                  End Date
                </label>
                <input
                  type="date"
                  name="end-date"
                  id="end-date"
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
                />
              </div>
            </div>
          )}
        </div>
      </div>
      
      {/* Report Preview */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Report Preview
          </h3>
        </div>
        <div className="px-4 py-5 sm:p-6">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            {/* Detections by Type */}
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h4 className="text-base font-medium text-gray-900 mb-4">
                Detections by Type
              </h4>
              <div className="h-64">
                <Pie 
                  data={detectionsByTypeData} 
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'bottom',
                      },
                    },
                  }}
                />
              </div>
            </div>
            
            {/* Detections Over Time */}
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h4 className="text-base font-medium text-gray-900 mb-4">
                Detections Over Time
              </h4>
              <div className="h-64">
                <Line 
                  data={detectionsByTimeData} 
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'bottom',
                      },
                    },
                    scales: {
                      y: {
                        beginAtZero: true,
                      },
                    },
                  }}
                />
              </div>
            </div>
            
            {/* Detections by Location */}
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h4 className="text-base font-medium text-gray-900 mb-4">
                Detections by Location
              </h4>
              <div className="h-64">
                <Bar 
                  data={detectionsByLocationData} 
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                    scales: {
                      y: {
                        beginAtZero: true,
                      },
                    },
                  }}
                />
              </div>
            </div>
            
            {/* Confidence Levels */}
            <div className="bg-white border border-gray-200 rounded-lg p-4">
              <h4 className="text-base font-medium text-gray-900 mb-4">
                Confidence Levels
              </h4>
              <div className="h-64">
                <Bar 
                  data={confidenceLevelsData} 
                  options={{
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        display: false,
                      },
                    },
                    scales: {
                      y: {
                        beginAtZero: true,
                      },
                    },
                  }}
                />
              </div>
            </div>
          </div>
          
          {/* Summary Statistics */}
          <div className="mt-6 border-t border-gray-200 pt-6">
            <h4 className="text-base font-medium text-gray-900 mb-4">
              Summary Statistics
            </h4>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-primary-100 rounded-md p-3">
                    <i className="bi bi-camera text-primary-600 text-xl"></i>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Total Detections
                      </dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">
                          132
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
              
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-danger-100 rounded-md p-3">
                    <i className="bi bi-fire text-danger-600 text-xl"></i>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Fire Detections
                      </dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">
                          65
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
              
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-warning-100 rounded-md p-3">
                    <i className="bi bi-cloud-haze text-warning-600 text-xl"></i>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Smoke Detections
                      </dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">
                          42
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
              
              <div className="bg-white border border-gray-200 rounded-lg p-4">
                <div className="flex items-center">
                  <div className="flex-shrink-0 bg-success-100 rounded-md p-3">
                    <i className="bi bi-check-circle text-success-600 text-xl"></i>
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Average Confidence
                      </dt>
                      <dd>
                        <div className="text-lg font-medium text-gray-900">
                          87.3%
                        </div>
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Key Insights */}
          <div className="mt-6 border-t border-gray-200 pt-6">
            <h4 className="text-base font-medium text-gray-900 mb-4">
              Key Insights
            </h4>
            <div className="bg-gray-50 rounded-lg p-4">
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-start">
                  <i className="bi bi-graph-up text-primary-600 mt-0.5 mr-2"></i>
                  <span>Fire detections have increased by 23% compared to the previous period.</span>
                </li>
                <li className="flex items-start">
                  <i className="bi bi-geo-alt text-primary-600 mt-0.5 mr-2"></i>
                  <span>Redwood Valley has the highest concentration of fire detections (30).</span>
                </li>
                <li className="flex items-start">
                  <i className="bi bi-calendar text-primary-600 mt-0.5 mr-2"></i>
                  <span>Most detections occur between 12:00 PM and 4:00 PM.</span>
                </li>
                <li className="flex items-start">
                  <i className="bi bi-lightning text-primary-600 mt-0.5 mr-2"></i>
                  <span>42 detections (32%) had a confidence level above 90%.</span>
                </li>
                <li className="flex items-start">
                  <i className="bi bi-exclamation-triangle text-primary-600 mt-0.5 mr-2"></i>
                  <span>Recommended to increase monitoring in the North Ridge area due to rising detection rates.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scheduled Reports */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Scheduled Reports
          </h3>
        </div>
        <div className="px-4 py-5 sm:p-6">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Report Name
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Frequency
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Recipients
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Sent
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">Weekly Summary</div>
                    <div className="text-sm text-gray-500">Summary report of all detections</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Weekly (Monday)
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    5 recipients
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Oct 16, 2023
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-pencil"></i>
                      </button>
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-send"></i>
                      </button>
                      <button
                        type="button"
                        className="text-danger-600 hover:text-danger-900"
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">Monthly Analysis</div>
                    <div className="text-sm text-gray-500">Detailed trend analysis</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Monthly (1st)
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    3 recipients
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Oct 1, 2023
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-pencil"></i>
                      </button>
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-send"></i>
                      </button>
                      <button
                        type="button"
                        className="text-danger-600 hover:text-danger-900"
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">Daily Alert Summary</div>
                    <div className="text-sm text-gray-500">Summary of daily alerts</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Daily (6:00 PM)
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    8 recipients
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Oct 19, 2023
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-pencil"></i>
                      </button>
                      <button
                        type="button"
                        className="text-primary-600 hover:text-primary-900"
                      >
                        <i className="bi bi-send"></i>
                      </button>
                      <button
                        type="button"
                        className="text-danger-600 hover:text-danger-900"
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          
          <div className="mt-4">
            <button
              type="button"
              className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              <i className="bi bi-plus mr-2"></i>
              Schedule New Report
            </button>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <div className="text-center text-sm text-gray-500 mt-8">
        <p>Forest Fire Detection System</p>
      </div>
    </div>
  );
};

export default Reports;
