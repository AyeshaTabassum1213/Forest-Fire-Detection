import { useState, useEffect } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import Sidebar from '../components/layout/Sidebar';
import Header from '../components/layout/Header';
import AlertBanner from '../components/alerts/AlertBanner';
import { useAlerts } from '../contexts/AlertContext';

const DashboardLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { currentUser, userRole } = useAuth();
  const { recentAlert } = useAlerts();
  const location = useLocation();
  const navigate = useNavigate();
  
  // Close sidebar on route change on mobile
  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);
  
  // Redirect to alert details when a new alert comes in
  useEffect(() => {
    if (recentAlert && location.pathname !== '/live-detection') {
      // Show alert banner instead of redirecting
    }
  }, [recentAlert, location.pathname, navigate]);

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-dark-100">
      {/* Sidebar */}
      <Sidebar 
        sidebarOpen={sidebarOpen} 
        setSidebarOpen={setSidebarOpen}
        userRole={userRole}
      />
      
      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <Header 
          setSidebarOpen={setSidebarOpen}
          user={currentUser}
          userRole={userRole}
        />
        
        {/* Alert Banner */}
        {recentAlert && <AlertBanner alert={recentAlert} />}
        
        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-100 p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
